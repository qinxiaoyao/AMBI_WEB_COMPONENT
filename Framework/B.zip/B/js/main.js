$(function() {

    //初始化导航菜单
    $('#side-menu').metisMenu();

    //左边导航菜单隐藏/显示
    $('.sidebar-toggle').on('click', function() {
        $('body').toggleClass('sidebar-collapse');
    });

    //面板的隐藏/显示
    $('.panel').on('click', '.panel-collapse', function() {
        var $panel = $(this).closest('.panel')
        $('.panel-heading .panel-collapse i', $panel).toggleClass('fa-caret-down').toggleClass('fa-caret-up')
        $('.panel-body', $panel).toggleClass('hidden')
    });


    $("[href='#ui']").trigger("click",function(){
        console.log("1");
    });


    //JSON to Nav
    function jsonToNav(data){
        $(".nav").html("");


    }


});
 